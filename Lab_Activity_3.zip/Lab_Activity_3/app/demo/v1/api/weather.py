# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

from flask import request, g

from . import Resource
from .. import schemas
from rivescript import RiveScript
import os
import re

username = 'swati'
bot = RiveScript(utf8=True)
bot.unicode_punctuation = re.compile(r'[.,!?;:]')
bot.load_directory(
        os.path.join(os.path.dirname(__file__), ".", "brain")
)
bot.sort_replies()

class Weather(Resource):

    def get(self):
        expression = g.args.get("expression")
        print("user says: %s" % expression)
        answer = bot.reply(username, expression)
        if "ERR" in answer:
            answer = "I dont know it"
        elif "=" in answer:
            print("Returned answer:{}".format(answer))

        return {"answer": answer}, 200, None








